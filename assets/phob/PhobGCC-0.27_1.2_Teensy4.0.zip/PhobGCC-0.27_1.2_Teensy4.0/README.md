# How to update the firmware on your Phob

## WARNING

MAKE ABSOLUTELY SURE YOUR PHOB MATCHES THE VERSIONS SPECIFIED IN THE FILENAME OF THE HEX FILE. If it doesn’t, this WILL NOT work and could make your controller unusable.

This bundle is for Phob 1.2.X boards with Teensy 4.0 **ONLY**. If your Phob doesn’t match these specs, do not use this hex file. If you aren’t completely sure, ask the person who made your Phob before proceeding.

## Full instructions

[View the guide](https://vulpinecustoms.com/resources/phob-firmware-update-guide) for a complete walkthrough with photos.

## Short version

1. **IMPORTANT: Unplug your controller from your console or adapter.** You should NEVER connect it via USB and the main cable at the same time.

2. Open teensy.exe if you’re using Windows, or Teensy.app if you’re using a Mac. A small window should open.

3. Press the green **Auto** button in the Teensy window so that it lights up.

4. Drag and drop the hex file included in this folder onto the Teensy window. You should now see the filename at the bottom of the window.

5. Plug the USB cable into your Phob and your computer (see full instructions for how to open your controller, etc).

6. Press the physical button on the front of the Teensy board on your controller. You should see some activity happen in the Teensy window, finishing with "Reboot OK".

That's it! You're now on the latest firmware.
